//base by DGXeon
//recode by Kiqozho
//YouTube: @KIQOZHO OFFICIAL
//Instagram: Kiqozho Official
//Telegram: t.me/6287819343311

const fs = require('fs')
const chalk = require('chalk')

//owmner v card
global.ytname = "KIQOZHO OFFICIAL" //ur yt chanel name
global.socialm = "QOZHO" //ur github or insta name
global.location = "Indonesia" //ur location

//new
global.botname = 'QOZHO' //ur bot name
global.ownernumber = '62xx' //ur owner number
global.ownername = 'QOZHO STORE' //ur owner name
global.websitex = "https://chat.whatsapp.com/G1JH8Q2AjdVFaptNYBHo9i"
global.wagc = "https://chat.whatsapp.com/JQGztHjlOb7J4CXhLZnk8Q"
global.themeemoji = '🪀'
global.wm = "QOZHO STORE"
global.botscript = 'https://wa.me/+6287819343311' //script link
global.packname = "QOZHO"
global.author = "QOZHO"
global.creator = "6287819343311@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["62xx"] // Premium User
global.hituet = 0

//bot sett
global.typemenu = 'v8' // menu type 'v1' => 'v8'
global.typereply = 'v2' // reply type 'v1' => 'v3'
global.autoblocknumber = '' //set autoblock country code
global.antiforeignnumber = '' //set anti foreign number country code
global.welcome = false //welcome/left in groups
global.anticall = false //bot blocks user when called
global.autoswview = true //auto status/story view
global.adminevent = false //show promote/demote message
global.groupevent = false //show update messages in group chat
//msg
global.mess = {
	limit: 'Your limit is up!',
	nsfw: 'Nsfw is disabled in this group, Please tell the admin to enable',
    done: 'Done✓',
    error: 'Error!',
    success: 'Succes'
}
//thumbnail
global.thumb = fs.readFileSync('./XeonMedia/theme/cheemspic.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})